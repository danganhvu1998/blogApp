<?php

header('Access-Control-Allow-Origin: *');
echo '{"resutl":0}';

?>