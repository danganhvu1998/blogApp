<?php

header('Access-Control-Allow-Origin: *');
echo "131231231231312312";
//echo $request;

?>