<?php

header('Access-Control-Allow-Origin: *');
echo "{";
echo '"result": '.$result;
echo "}";

?>